import {ObjPost} from './post';

export const TABPOSTS: ObjPost[] = [
    // tslint:disable-next-line:max-line-length
    { title: 'Mon premier post', content: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc vehicula dui eget tincidunt dictum. Sed eget mauris lorem. Maecenas at tincidunt leo. Maecenas hendrerit, est eget congue fermentum, nisi diam lacinia arcu, eget ultricies sapien libero eu est.', loveIts: 5, created_at: null},
    // tslint:disable-next-line:max-line-length
    { title: 'Mon deuxième post', content: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc vehicula dui eget tincidunt dictum. Sed eget mauris lorem. Maecenas at tincidunt leo. Maecenas hendrerit, est eget congue fermentum, nisi diam lacinia arcu, eget ultricies sapien libero eu est. Pellentesque vitae diam ac justo pretium convallis. In at felis massa.', loveIts: -4, created_at: null},
    // tslint:disable-next-line:max-line-length
    { title: 'Encore un post', content: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc vehicula dui eget tincidunt dictum. Sed eget mauris lorem. Maecenas at tincidunt leo. Maecenas hendrerit, est eget congue fermentum, nisi diam lacinia arcu, eget ultricies sapien libero eu est. Pellentesque vitae diam ac justo pretium convallis. In at felis massa. Praesent mauris metus, elementum vitae tincidunt quis, aliquet eu augue. Pellentesque ante mi, pretium in facilisis et, fringilla ut tortor.', loveIts: 0, created_at: null},
];
