export class ObjPost {
    title: string;
    content: string;
    loveIts: number;
    created_at: Date;
}
